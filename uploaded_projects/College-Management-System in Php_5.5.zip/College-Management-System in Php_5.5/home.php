<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>College management system made by Rajendra Arora..</title>
</head>

<body>
	<div class="panel panel-default">
  		<div class="panel-heading"><h1>College Management System</h1></div>
                <div class="panel-body"><br><br>
        <div>
            <img src="images/rtupic.jpg" width="855" style="text-align: center;" height="308" onmousedown="return false;"  />
        </div><br><br>
        <div class="middle_text">
            <p><strong>Rajasthan Technical University (RTU) is an affiliating university located in Kota in the state of Rajasthan, India. The university was established in 2006.</strong></p>
        </div>
                
        <div class="text_para_home">
            <p>RTU is an affiliating university. Its affiliated colleges offer the degrees of Bachelor of Technology (B.Tech), Master of Technology (M.Tech), Master of Business Administration (MBA), Master of Computer Applications (MCA) and Bachelor of Hotel Management and Catering Technology (BHMCT).
As of April 2011, RTU affiliates 202 colleges. B.Tech degrees are offered at nine government aided institutes and 109 are private ones. MBA degrees are offered at seven government aided institutes and 122 are private ones. MCA degrees are offered in at seven government aided institutes and 25 are private ones. M.Tech is offered in 24 colleges and BHMCT in four colleges. In addition, two colleges offer Bachelor of Architecture (B.Arch) degrees. Rajasthan University Publishes Courses Results Semester wise.</p>         
        </div>   
                </div>
        </div>
    
    
</body>
</html>