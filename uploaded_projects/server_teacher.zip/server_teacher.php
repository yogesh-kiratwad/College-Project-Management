<?php

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$gender=$_POST['gender'];
$dob=$_POST['yy']."/".$_POST['mm']."/".$_POST['dd'];
$pob = $_POST['pob'];
$address = $_POST['address'];
$degree=$_POST['degree'];
$salary=$_POST['salary'];
$married=$_POST['married'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$note = $_POST['note'];

if (!empty($fname) || !empty($lname) || !empty($gender) || !empty($dob)|| !empty($pob) || !empty($address) || !empty($degree) || !empty($salary) || !empty($married) || !empty($mobile) || !empty($email) || !empty($note)) {
    $host="localhost";
    $dbUsername="root";
    $dbPassword="";
    $dbname="project";

    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
        die('Connect Error('. mysqli_connect_error().')'. mysqli_connect_error());
    }
    else {
        $sql = "INSERT INTO teacher(fname, lname, gender, date, pob, address, degree, salary, married, mobile, email, note) values ('$fname', '$lname','$gender', '$dob', '$pob', '$address', '$degree', '$salary', '$married', '$mobile', '$email', '$note')";

            if ($conn->query($sql)) {
            echo "<script>alert('Success')</script>";
            
                header("Location: server.html");
            }
            else {
            echo "Error: ". $sql ."<br>". $conn->error;
            }
        $conn->close();
    }
}
else {
    echo "All fields are required.";
    die();
}

?>